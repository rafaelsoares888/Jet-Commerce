﻿import {_alert, _confirm} from './message';

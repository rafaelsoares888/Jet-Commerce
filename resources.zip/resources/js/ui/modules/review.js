/**
 * Semantic-UI Rating
 * Incialização das estrelas de Rating e Review
 */
